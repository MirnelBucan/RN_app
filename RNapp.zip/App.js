import React from 'react';
import AppContainer from './navigation/AppNavigation'


export default class App extends React.Component {
  render() {
    return (
      <AppContainer />
    );
  }
}
